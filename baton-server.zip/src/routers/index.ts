// import then re-export all routers here

export { default as router } from './root';