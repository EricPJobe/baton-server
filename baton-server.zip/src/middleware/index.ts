// import then re-export all middleware here

export { default as logger } from './logger';