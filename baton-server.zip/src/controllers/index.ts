//import then re-export all controllers here

export { default as controller } from './default';